using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class EnemyController : MonoBehaviour
{
    public GameObject fireball;
    public float speedEnemy;
    public LayerMask border;
    const string STATE_ATTACKING = "enemy_attacking";
    const string STATE_SLIDING = "enemy_sliding";
    Animator enemyAnimator;
    bool isLookingRight;
    bool startMovement;


    // Start is called before the first frame update
    void Start()
    {
        enemyAnimator = GetComponent<Animator>();
        isLookingRight = true;
        startMovement = false;
        StartCoroutine(Fire(2.8f));
    }

    // Update is called once per frame
    void Update()
    {
        Debug.DrawRay(this.transform.position,Vector2.down * 1.6f,Color.black);
        //moves the enemy arround
        if(startMovement){
            if(isLookingRight){
                transform.position = new Vector2(transform.position.x + speedEnemy,this.transform.position.y);
                transform.eulerAngles = new Vector2(0,0);
            }else{
                transform.position = new Vector2(transform.position.x - speedEnemy,this.transform.position.y);
                transform.eulerAngles = new Vector2(0,180);
            }

            //change in what direction the enemy moves on
            if(isOnBorder() && isLookingRight){
                isLookingRight = false;
            }else if(isOnBorder() && isLookingRight == false){
                isLookingRight = true;
            }
        }
    }


    //i create an elemenent called border, when the raycast from the enemy touch the border will change his direction
    bool isOnBorder(){
        if(Physics2D.Raycast(this.transform.position,Vector2.down,1.6f,border)){
            return true;
        }else{
            return false;
        }
    }
    
    

    //i verified the Unity subrutines in differente youtube videos
    IEnumerator Fire(float time){

        //thanks to this tuto https://docs.unity3d.com/ScriptReference/Object.Instantiate.html
        //and this other tuto https://docs.unity3d.com/es/530/Manual/CreateDestroyObjects.html
        yield return new WaitForSeconds(time);

        enemyAnimator.SetBool(STATE_SLIDING, true);
        
        yield return new WaitForSeconds(0.4f);
        startMovement = true;

        yield return new WaitForSeconds(1.4f);

        enemyAnimator.SetBool(STATE_SLIDING,false);
        startMovement = false;
        enemyAnimator.SetBool(STATE_ATTACKING, true);

        yield return new WaitForSeconds(1.65f);
        
        enemyAnimator.SetBool(STATE_ATTACKING, false);
        if (isLookingRight){
            Instantiate(fireball, new Vector2(this.transform.position.x + 1,this.transform.position.y), this.transform.rotation);
        }else{
            Instantiate(fireball, new Vector2(this.transform.position.x - 1,this.transform.position.y), this.transform.rotation);
        }

        StartCoroutine(Fire(time));
    }

}
