using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public enum PlayerStatus{
    attacking,
    vulnerable,
    invencible
}

public class PlayerController : MonoBehaviour
{
    //consts to manage the player animation
    const string STATE_ALIVE = "isAlive";
    const string STATE_RUN = "isRunning";
    const string STATE_GROUND = "isOnTheGround";
    const string STATE_JUMPING = "isJumping";
    const string STATE_FALLING = "isFalling";
    const string STATE_KICKING = "isKicking";
    const string STATE_PUNCHING = "isPunching";
    const string STATE_BLOCK = "isBlocking";
    Animator playerAnimator;
    Rigidbody2D rigidBody;
    public float jumpForce;
    public float speed;
    public float speedPrev;
    public PlayerStatus status;
    public LayerMask groundMask;
    public GameObject restartPlay;
    public GameObject mainMenu;
    public Image GameOver;
    private float lastYPosition;
    

    void Awake(){
        playerAnimator = GetComponent<Animator>();
        rigidBody = GetComponent<Rigidbody2D>();   
    }

    // Start is called before the first frame update
    void Start()
    {
        speedPrev = speed;
        lastYPosition = 0;
        playerAnimator.SetBool(STATE_ALIVE,true);
        GameOver.enabled = false;
        restartPlay.gameObject.SetActive(false);
        mainMenu.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {

        //move the player
        //normally i transform the position but after see this https://docs.unity3d.com/ScriptReference/Input.GetAxis.html
        // i think that is better update the position from the player in seconds instead frames
        float translation = Input.GetAxis("Horizontal") * speed;
        // Make it move 10 meters per second instead of 10 meters per frame...
        translation *= Time.deltaTime;

        // Move translation along the x-axis
        transform.Translate(translation, 0, 0);

        //jump
        if(Input.GetKeyDown(KeyCode.UpArrow)){
            playerAnimator.SetBool(STATE_JUMPING,true);//change animation
            Jump();
        }

        Debug.DrawRay(this.transform.position,Vector2.down*1.2f,Color.black);

        /////ATTACKS

        if(Input.GetKeyDown(KeyCode.Z)){//animate kick when player press z
            stopAttack();
            playerAnimator.SetBool(STATE_RUN,false);
            playerAnimator.SetBool(STATE_KICKING, true);
            status = PlayerStatus.attacking;
            Invoke("stopAttack",0.417f);
        } 
        
        if (Input.GetKeyDown(KeyCode.X)){//animate fist when player press x 
            stopAttack();
            playerAnimator.SetBool(STATE_RUN,false);
            playerAnimator.SetBool(STATE_PUNCHING, true);
            status = PlayerStatus.attacking;
            Invoke("stopAttack",0.5f);
        }

        if (Input.GetKey(KeyCode.Q) && IsTouchingTheGround()){//animate fist when player press q
            stopAttack();
            playerAnimator.SetBool(STATE_RUN,false);
            playerAnimator.SetBool(STATE_BLOCK, true);
            status = PlayerStatus.invencible;
            speed = 0;
        }
        if(Input.GetKeyUp(KeyCode.Q)){
            playerAnimator.SetBool(STATE_BLOCK, false);
            status = PlayerStatus.vulnerable;
            speed = speedPrev;

        }

        ////Movement

        if(lastYPosition > this.transform.position.y){//if player is falling change animation to fall
            playerAnimator.SetBool(STATE_JUMPING,false);
            playerAnimator.SetBool(STATE_FALLING,true);
        }

        if(lastYPosition < this.transform.position.y){//if player is jumpimg change animation tojump
            playerAnimator.SetBool(STATE_JUMPING,true);
        }

        if(IsTouchingTheGround()){//if player is touching the ground stop jump and fall
            playerAnimator.SetBool(STATE_JUMPING,false);
            playerAnimator.SetBool(STATE_FALLING,false);
            playerAnimator.SetBool(STATE_GROUND,true);
        }else{
            playerAnimator.SetBool(STATE_GROUND,false);
        }

        if(Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.LeftArrow)){
            playerAnimator.SetBool(STATE_RUN,true);
        }else if(Input.GetKeyUp(KeyCode.RightArrow) || Input.GetKeyUp(KeyCode.LeftArrow)){
            playerAnimator.SetBool(STATE_RUN,false);
        }
        //stop the jump animationsto fix the trouble when go back to the ground
        if(IsTouchingTheGround()){
            playerAnimator.SetBool(STATE_GROUND,true);
        }

        //flip the player
        if(Input.GetKeyDown(KeyCode.RightArrow) && rigidBody.transform.localScale.x < 0){
            rigidBody.transform.localScale = new Vector2(5.87307f, 4.981125f);
        }else if(Input.GetKeyDown(KeyCode.LeftArrow) && rigidBody.transform.localScale.x > 0){
            rigidBody.transform.localScale = new Vector2(-5.87307f, 4.981125f);
        }

        //die for fall
        if(this.transform.position.y <= -11.5f){
            die();
        }

        lastYPosition = this.transform.position.y;//i need to know what is the y all the time to be able to know when the player is falling
    }

    void Jump()
    {
        if(IsTouchingTheGround()){
            rigidBody.AddForce(Vector2.up*jumpForce, ForceMode2D.Impulse);
        }
    }

    //is the player or not touching the code
    bool IsTouchingTheGround(){
        if(Physics2D.Raycast(this.transform.position,Vector2.down,1.2f,groundMask)){
            return true;
        }else{
            return false;
        }
    }
    
    void stopAttack(){
        status = PlayerStatus.vulnerable;
        playerAnimator.SetBool(STATE_PUNCHING, false);
        playerAnimator.SetBool(STATE_KICKING, false);
        playerAnimator.SetBool(STATE_BLOCK, false);
    }

    void OnCollisionEnter2D(Collision2D collision){
        Debug.Log("Se estrello con: "+collision.gameObject.tag);
        Debug.Log("Status es: "+collision.gameObject.tag);
        if (collision == null){return;}
        if (collision.collider.CompareTag("enemy") && status == PlayerStatus.attacking){
            collision.gameObject.GetComponent<Animator>().SetBool("die",true);
            collision.gameObject.GetComponent<EnemyController>().speedEnemy = 0;
            Destroy(collision.gameObject,3.0f);
            collision = null;
        }
        if (collision.collider.CompareTag("enemy") && status == PlayerStatus.vulnerable){
            die();
        }

        if (collision.collider.CompareTag("enemy") && status == PlayerStatus.invencible){
            die();
        }

        if (collision.collider.CompareTag("fire") && status == PlayerStatus.invencible){
            Destroy(collision.gameObject);
            collision = null;
        }
        if (collision.collider.CompareTag("fire") && status == PlayerStatus.vulnerable){
            die();
        }
        if (collision.collider.CompareTag("fire") && status == PlayerStatus.attacking){
            die();
        }
    }

    void die(){
        speed = 0;
        transform.position = new Vector2(transform.position.x,transform.position.y - 0.5f);
        playerAnimator.SetBool(STATE_ALIVE,false);
        Destroy(gameObject,1.3f);
        GameOver.enabled = true;
        restartPlay.gameObject.SetActive(true);
        mainMenu.gameObject.SetActive(true);
    }
}
