using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireBallController : MonoBehaviour
{
    //thanks to this video https://www.youtube.com/watch?v=ZUkfocZDoms
    Rigidbody2D fire;
    public float speedFireBall;
    // Start is called before the first frame update
    void Start()
    {
        fire = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        fire.velocity = transform.right * speedFireBall;
        Destroy(gameObject, 5f);
    }
}
