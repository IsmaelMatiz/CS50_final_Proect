using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class background_controller : MonoBehaviour
{

    private Material material;
    private int currentScene;
    public GameObject target;

    void Awake(){
        material = GetComponent<SpriteRenderer>().material;
        currentScene = SceneManager.GetActiveScene().buildIndex;
    }

    // Update is called once per frame
    void Update()
    {
        //Credits to that video to xplain how to make a good parallax https://www.youtube.com/watch?v=7bJT6rf-Jvk
        //in the video he use the velocity component, but my character go ahead using translate not velocity
        //for that reason i just replace it with a new vector2 that is equals to a little fraction 
        //of the player's x position and its updated on each frame
        if(currentScene == 1){
            transform.position = new Vector3(target.transform.position.x,20.0f);
            material.mainTextureOffset = new Vector2((target.transform.position.x * 0.01f),0);
        }

        if(currentScene == 2 || currentScene == 3){
            transform.position = new Vector3(target.transform.position.x,6.0f);
            material.mainTextureOffset = new Vector2((target.transform.position.x * 0.01f),0);
        }
    }
}
