using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    public GameObject target;
    Vector3 camAdjust;
    public float ahead;
    public float smooth;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //special thanks to this video https://www.youtube.com/watch?v=_f4nI8FtVqQ
        //update my camera position relative to the target and with a smooth efect
        //if the user is locking to the right we need sum the actual position + how ahead we want to move the camera otherwise sustract
        if(target.transform.localScale.x > 0){
            camAdjust = new Vector3(target.transform.position.x + ahead, target.transform.position.y + 4,-10);
        }else if (target.transform.localScale.x < 0){
            camAdjust = new Vector3(target.transform.position.x - ahead, target.transform.position.y + 4,-10);
        }

        transform.position = Vector3.Lerp(transform.position,camAdjust, smooth * Time.deltaTime);
    }
}
