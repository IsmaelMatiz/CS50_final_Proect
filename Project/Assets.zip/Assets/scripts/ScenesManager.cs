using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class ScenesManager : MonoBehaviour
{
    int currentScene;

    public void Start()
    {
        currentScene = SceneManager.GetActiveScene().buildIndex;
        // This is only if we are in the finish message go back to the beginning after 40 seconds
        if (currentScene == 4){
            Invoke("GoToMenu",40.0f);
        }
    }

    public void OnCollisionEnter2D(){
        NextLevel();
    }

    public void NextLevel()
    {
        SceneManager.LoadScene(currentScene + 1);
    }
    
    public void GoToMenu(){
        SceneManager.LoadScene(0);
    }

    public void Restart(){
        //the same than next level but resume just in One line and to load again the current scene
        SceneManager.LoadScene(currentScene);
    }

    public void CloseGame(){
        Application.Quit();
    }

}
