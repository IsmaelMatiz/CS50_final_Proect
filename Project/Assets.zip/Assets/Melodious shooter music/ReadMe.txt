Melodious shooter music

Thank you download this package.
Three BGMs for action games or shooting games.
There are three types of tempo, three types of the number of loops, once, twice, three times. Please use your preference.

Composed by Sosu-Meikyu
http://sosumeikyu.net/

